
import { useState } from "react";
import FormSuratJalan from "./FormSuratJalan";
import SuratJalanList from "./SuratJalanList";
import UserManagement from "./UserManagement";

export default function Dashboard({ user, setUser }) {
  const [suratJalanList, setSuratJalanList] = useState([]);
  const [editing, setEditing] = useState(null);

  const handleLogout = () => setUser(null);
  const handleSave = (data) => {
    if (editing !== null) {
      const updated = suratJalanList.map((s, i) => (i === editing ? data : s));
      setSuratJalanList(updated);
    } else {
      setSuratJalanList([...suratJalanList, data]);
    }
    setEditing(null);
  };

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Dashboard ({user.role})</h2>
        <button onClick={handleLogout} className="bg-red-500 text-white px-4 py-2 rounded">Logout</button>
      </div>
      <FormSuratJalan onSave={handleSave} existing={editing !== null ? suratJalanList[editing] : null} />
      <SuratJalanList items={suratJalanList} role={user.role} onEdit={(index) => setEditing(index)} />
      {user.role === "admin" && <UserManagement />}
    </div>
  );
}
