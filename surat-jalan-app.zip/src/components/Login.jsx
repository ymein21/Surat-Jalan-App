
import { useState } from "react";
export default function Login({ setUser }) {
  const [username, setUsername] = useState("");
  const [role, setRole] = useState("driver");

  const handleLogin = () => {
    if (username) {
      setUser({ name: username, role });
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <h1 className="text-2xl font-bold mb-4">Login</h1>
      <input className="border p-2 mb-2" placeholder="Nama" value={username} onChange={(e) => setUsername(e.target.value)} />
      <select className="border p-2 mb-4" value={role} onChange={(e) => setRole(e.target.value)}>
        <option value="admin">Admin</option>
        <option value="driver">Driver</option>
      </select>
      <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={handleLogin}>Login</button>
    </div>
  );
}
