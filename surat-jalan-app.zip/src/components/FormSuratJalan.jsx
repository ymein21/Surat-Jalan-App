
import { useState, useEffect } from "react";
export default function FormSuratJalan({ onSave, existing }) {
  const [form, setForm] = useState({
    nomor: "", tanggal: "", driver: "", kendaraan: "", tujuan: "", deskripsi: "", catatan: ""
  });
  useEffect(() => { if (existing) setForm(existing); }, [existing]);
  const handleChange = (e) => { setForm({ ...form, [e.target.name]: e.target.value }); };
  const handleSubmit = () => { if (form.nomor && form.tanggal) onSave(form); };

  return (
    <div className="mb-4">
      <h3 className="font-semibold mb-2">Form Surat Jalan</h3>
      <div className="grid grid-cols-2 gap-2">
        {Object.keys(form).map((key) => (
          <input key={key} name={key} value={form[key]} onChange={handleChange} className="border p-2" placeholder={key} />
        ))}
      </div>
      <button className="bg-green-500 text-white px-4 py-2 mt-2" onClick={handleSubmit}>Simpan</button>
    </div>
  );
}
