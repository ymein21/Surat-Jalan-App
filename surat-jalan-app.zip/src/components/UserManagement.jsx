
export default function UserManagement() {
  return (
    <div className="mt-6">
      <h3 className="font-semibold mb-2">Manajemen User (Mocked)</h3>
      <p>Fitur ini hanya sebagai placeholder. Bisa dihubungkan ke backend nanti.</p>
    </div>
  );
}
