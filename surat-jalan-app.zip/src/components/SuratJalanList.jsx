
import jsPDF from "jspdf";
export default function SuratJalanList({ items, role, onEdit }) {
  const generatePDF = (item) => {
    const doc = new jsPDF();
    doc.text("Surat Jalan", 10, 10);
    Object.entries(item).forEach(([key, val], i) => {
      doc.text(`${key}: ${val}`, 10, 20 + i * 10);
    });
    doc.save(`surat-jalan-${item.nomor}.pdf`);
  };

  return (
    <div className="mt-4">
      <h3 className="font-semibold mb-2">Daftar Surat Jalan</h3>
      {items.map((item, i) => (
        <div key={i} className="border p-2 mb-2 flex justify-between items-center bg-gray-100">
          <div><strong>{item.nomor}</strong> - {item.tujuan}</div>
          <div className="space-x-2">
            <button className="bg-blue-500 text-white px-2 py-1" onClick={() => generatePDF(item)}>PDF</button>
            {(role === "admin" || role === "driver") && (
              <button className="bg-yellow-500 text-white px-2 py-1" onClick={() => onEdit(i)}>Edit</button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
